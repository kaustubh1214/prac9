import React from "react";

const Home = () => {
  return (
    <div className="text-center mt-10">
      <h1 className="text-4xl font-bold">Welcome to Our Restaurant</h1>
      <p className="mt-4">Enjoy delicious food and great ambiance!</p>
    </div>
  );
};

export default Home;
