import React from "react";

const About = () => {
  return (
    <div className="text-center mt-10">
      <h1 className="text-4xl font-bold">About Us</h1>
      <p className="mt-4">We serve fresh and delicious food every day!</p>
    </div>
  );
};

export default About;
