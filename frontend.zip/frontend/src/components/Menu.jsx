import React from "react";

const Menu = () => {
  return (
    <div className="text-center mt-10">
      <h1 className="text-4xl font-bold">Our Menu</h1>
      <ul className="mt-6">
        <li>Pasta</li>
        <li>Pizza</li>
        <li>Burger</li>
        <li>Ice Cream</li>
      </ul>
    </div>
  );
};

export default Menu;
