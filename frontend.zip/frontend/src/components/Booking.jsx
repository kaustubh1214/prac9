import React, { useState, useEffect } from "react";

const Booking = () => {
  const [formData, setFormData] = useState({ name: "", lastname: "", phone: "", date: "", time: "" });
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/bookings")
      .then((res) => res.json())
      .then(setBookings)
      .catch(console.error);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost:5000/api/bookings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    })
      .then((res) => res.json())
      .then((newBooking) => setBookings([...bookings, newBooking]))
      .catch(console.error);
    setFormData({ name: "", lastname: "", phone: "", date: "", time: "" });
  };

  return (
    <div className="text-center mt-10">
      <h1 className="text-4xl font-bold">Book a Table</h1>
      <form className="max-w-md mx-auto mt-6" onSubmit={handleSubmit}>
        <input name="name" value={formData.name} onChange={handleChange} placeholder="Name" className="block w-full p-2 mb-4 border rounded" required />
        <input name="lastname" value={formData.lastname} onChange={handleChange} placeholder="Last Name" className="block w-full p-2 mb-4 border rounded" required />
        <input name="phone" value={formData.phone} onChange={handleChange} placeholder="Phone" className="block w-full p-2 mb-4 border rounded" required />
        <input type="date" name="date" value={formData.date} onChange={handleChange} className="block w-full p-2 mb-4 border rounded" required />
        <input type="time" name="time" value={formData.time} onChange={handleChange} className="block w-full p-2 mb-4 border rounded" required />
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Submit</button>
      </form>

      <h2 className="text-2xl font-bold mt-10">Current Bookings</h2>
      <table className="table-auto mx-auto mt-4 border-collapse border border-gray-300">
        <thead>
          <tr>
            <th className="border border-gray-300 px-4 py-2">Name</th>
            <th className="border border-gray-300 px-4 py-2">Last Name</th>
            <th className="border border-gray-300 px-4 py-2">Phone</th>
            <th className="border border-gray-300 px-4 py-2">Date</th>
            <th className="border border-gray-300 px-4 py-2">Time</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((b, i) => (
            <tr key={i}>
              <td className="border border-gray-300 px-4 py-2">{b.name}</td>
              <td className="border border-gray-300 px-4 py-2">{b.lastname}</td>
              <td className="border border-gray-300 px-4 py-2">{b.phone}</td>
              <td className="border border-gray-300 px-4 py-2">{b.date}</td>
              <td className="border border-gray-300 px-4 py-2">{b.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Booking;
